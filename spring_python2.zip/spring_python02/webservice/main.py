'''
Created on 2019. 11. 1.

@author: Leewg

Flask 웹 서비스 메인 모듈

'''
#Flask 접속.
from flask import Flask, render_template, request, jsonify, request, Response

# 피어슨 상관 - 추천 시스템 모듈 
from recomend.video_Q import dbGetData, pearsonRecommend

app = Flask(__name__)

@app.route ( "/" )
def home():
    
    # get 방식 요청 파라미터를 읽어온다. 지정한 요청 파라미터가 없으면 None이 넘어온다.
    method = request.args.get( "method" )
    print( "home() - method : " , method)
    userId = request.args.get("userId")
    
    if not userId:
        userId = "yujin"

    # 요청 방식이 GET 방식인지 POST 방식인지 다음과 같이 확인할 수 있다.
    print( "methods : " , request.method)
    print( "home() - userId: " , userId)
    
    dbDf = dbGetData()
    
    rec = pearsonRecommend(dbDf, userId)
    
    videoNames = rec["index"]
    print("정보 보기 :\n", videoNames)
    
    #req_param=[]
    #for i in videoNames:
    #    req_param.append(i)
    # parameter로 req_param를 보내면 저쪽에서 parameter로 받아야함 
    #print("req_param:", req_param)
    
    # 카테고리 결과로 영상의 이름을 추출할 사전 데이터
    """
    index= ["YusansoQ1", "YusansoQ2", "YusansoQ3","BoggeunQ1","BoggeunQ2","BoggeunQ3", 
    "Upper_bodyQ1","Upper_bodyQ2","Upper_bodyQ3","Lower_bodyQ1",
    "Lower_bodyQ2","Lower_bodyQ3","StretchingQ1","StretchingQ2","StretchingQ3"]
    """
    videoDict = {}
    videoDict["YusansoQ3"] = "aerobiceasy.mp4"
    videoDict["YusansoQ2"] = "aerobicmiddle.mp4"
    videoDict["YusansoQ1"] = "aerobichigh.mp4"
    
    videoDict["BoggeunQ3"] = "coreeasy.mp4"
    videoDict["BoggeunQ2"] = "coremiddle.mp4"
    videoDict["BoggeunQ1"] = "corehigh.mp4"
    
    videoDict["Upper_bodyQ3"] = "upperbodyeasy.mp4"
    videoDict["Upper_bodyQ2"] = "upperbodymiddle.mp4"
    videoDict["Upper_bodyQ1"] = "upperbodyhigh.mp4"
    
    videoDict["Lower_bodyQ3"] = "lowerbodyeasy.mp4"
    videoDict["Lower_bodyQ2"] = "lowerbodymiddle.mp4"
    videoDict["Lower_bodyQ1"] = "lowerbodyhigh.mp4"
    
    videoDict["StretchingQ3"] = "stretchingeasy.mp4"
    videoDict["StretchingQ2"] = "stretchingmiddle.mp4"
    videoDict["StretchingQ1"] = "stretchinghigh.mp4"

    videoList = []

    for item in videoNames:
        videoList.append(videoDict[item])
    

    # 화면에 출력할 템플릿 페이지를 반환하면서 모델 데이터를 인수로 지정할 수 있다.
    # 현재 모듈이 실행되는 위치에서 templates/index.html 파일을 찾는다.
    # 뷰 페이지에서 사용할 모델 데이터를 method 이름으로 같이 보낸다.
    #return render_template( "rank.html" , videoNames = list(videoNames), videoList=videoList)
    #listData = list(videoNames)    
    
    res = Response()
    res.headers.add("Access-Control-Allow-Origin", "*")
    res.set_data(str(videoList))
    
    return res
    

# 사전 데이터를 JSON 형식으로 변환해 반환할 수 있음
#return jsonify({"msg": req_msg})

# 현재 모듈이 main으로 실행되면 웹 서비스를 시작한다.
if __name__ ==  "__main__" :
    
    # host 옵션을 생략하거나 "localhost"로 지정하면 현재 모듈을 로컬 서버로 실행한다.
    # host를 아래와 같이 "0.0.0.0"으로 지정하면 다른 컴퓨터에서 접근가능하다.
    #app.run(host= "0.0.0.0" , port=9000)
    # 개발 할때만 debug 옵션을 지정하고 실제 운영에서는 debug 옵션을 제거한다.
    app.run(host="0.0.0.0", port=9000, debug=True)
