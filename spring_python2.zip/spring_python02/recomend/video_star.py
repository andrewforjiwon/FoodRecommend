'''
Created on 2019. 10. 28.

@author: Leewg

[카테고리별 - 별점]
'''
import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import font_manager, rc #한글이 나오도록 구성
font_name = font_manager.FontProperties(fname="c:/windows/Fonts/malgun.ttf").get_name()
rc('font', family=font_name)

#DB데이터 가져오기 
import pymysql
db = pymysql.connect(host='127.0.0.1', port=3306, user='root', passwd='12345678', db='python', charset='utf8')
try:
    cursor = db.cursor()
    sql = "SELECT * FROM video_star"
    cursor.execute(sql)
    result = cursor.fetchall()
    
    print(result)
    
    indexL=[]
    userL=[]
    catL=[]
    scoreL=[]
    
    
    for i in result:
        index, user_id, video_type, star_rate=i
        indexL.append(index)
        userL.append(user_id)
        catL.append(video_type)
        scoreL.append(star_rate)
        
    print(indexL)
    print(userL)
    print(catL)
    print(scoreL)
    ratings=pd.DataFrame({
        "index":indexL,
        "user_id":userL,
        "video_type":catL,
        "star_rate":scoreL
        })
    #print(ratings)
          
finally:
    db.close()
    
    
# 1. 리뷰어 별로 각 카테고리 영상에 몇점을 주었는가?
video = ratings.pivot(index = 'video_type', columns = 'user_id', \
                        values = 'star_rate').reset_index()
#print(video)

# 2. 사용자 사이의 유사도 계산
sim_users = video.corr(method='pearson').reset_index()
#print(sim_users)

# 2-1. 사용자 사이의 유사도 히트맵 
plt.figure(figsize=(9,9))
sns.heatmap(video.corr(method='pearson'), annot=True, fmt='.3f', cmap='RdYlGn', linewidth=.5)
sns.set(font_scale=1)
plt.yticks(np.arange(0.5, len(video.corr(method='pearson').index),1), video.corr(method='pearson').index)
plt.xticks(np.arange(0.5, len(video.corr(method='pearson').columns),1), video.corr(method='pearson').columns)
plt.grid(False)
plt.xlabel("user", size=30)
plt.ylabel("user", size=30)
plt.title("Rate Matrix", size=40)
plt.show()

#1. A가 평가하지 않은 카테고리 영상을 골라낸다.

rating_critic = pd.DataFrame(video).reset_index()
rating_critic.rename(columns={'A':'video_rate'}, inplace = True) # 'A'특정유저를집어넣는것  
#print(rating_critic)
# A를 평점으로 Rename(이름변경)하고 NaN값만 뽑아내자.

# 2. A가 평가하지 않은// 자기평점보다 낮은 카테고리 영상을 뽑아낸다
titles_na_critic = rating_critic.video_type[rating_critic.video_rate < video.A.mean()] #특정유저A 평점
titles_na_critic = list(titles_na_critic.values)
#print(titles_na_critic)

# 3. 원본데이터에서 위 A가 안본 영상을 예측한 등급을 가져온다
rating_t = ratings[ratings.apply(lambda x : x.video_type in titles_na_critic, axis=1)]
#print(rating_t)

# 4. A와의 유사도 추가 / 특정유저 'A'처럼값이들어감/ 

rating_t = pd.merge(rating_t, sim_users[['user_id','A']], on='user_id')
rating_t.rename(columns={'A':'similarity'}, inplace = True)
#print(rating_t)

# 별점등급과 유사도 값을 구한 column생성
rating_t['sim_rating'] = rating_t.star_rate * rating_t.similarity
#print(rating_t)  

# A의 예상 점수를 구한다
rate_temp = rating_t.groupby(['video_type']).sum()
rate_temp['predict'] = (rate_temp.sim_rating / rate_temp.similarity)
print("------------------------[해당user 별점 예상점수로 추천 순위]----------------------------------")
print(rate_temp.predict.sort_values(ascending=False))
print("------------------------[user간 별점 평균]----------------------------------")
print(video.mean())
# 결론 = 해당user에 평균보다 높은거나 가까운 (카테고리)를 추천할 수 있다.

from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route ( "/" )
def home():
# get 방식 요청 파라미터를 읽어온다. 지정한 요청 파라미터가 없으면 None이 넘어온다.
    method = request.args.get( "method" )
    print( "home() - method : " , method)
# 요청 방식이 GET 방식인지 POST 방식인지 다음과 같이 확인할 수 있다.
    print( "methods : " , request.method)
# 화면에 출력할 템플릿 페이지를 반환하면서 모델 데이터를 인수로 지정할 수 있다.
# 현재 모듈이 실행되는 위치에서 templates/index.html 파일을 찾는다.
# 뷰 페이지에서 사용할 모델 데이터를 method 이름으로 같이 보낸다.
    return render_template( "index.html" , method = method)
# 프로그램 요소가 없는 정적 파일이라면 아래와 같이 지정해도 된다.
# 현재 모듈이 실행되는 위치에서 static/home.html 파일을 찾는다.
# @app.route("/", static_folder=".", static_url_path="")
# return app.send_static_file("home.html")

# 서버의 /chat 으로 들어오는 get 방식 요청을 처리하는 chat_get() 함수를 엔드포인트로 등록
@app.route ( "/chat" , methods=[ "GET" ])
def chat_get():
# 요청 방식이 GET 방식인지 POST 방식인지 다음과 같이 확인할 수 있다.
    print( "methods : " , request.method)
# get 방식 요청 파라미터를 읽어온다. 지정한 요청 파라미터가 없으면 None이 반환된다.
    one = request.args.get( "one" )
    two = request.args.get( "two" )
    three = request.args.get( "three" )
    four = request.args.get( "four" )
    five = request.args.get( "five" )
    type_st = request.args.get( "type_st" )
# 템플릿 페이지(뷰 페이지)를 반환하면서 모델 정보를 인수로 지정할 수 있다.
# 현재 모듈이 실행되는 위치에서 templates/chatting.html을 찾는다.
# 뷰 페이지로 보낼 모델이 여러 개라면 아래와 같이 가변인수를 사용할 수 있다.
    return render_template( "rank.html" , one = one, two = two, three=three, four=four, five=five, type_st = type_st)

# 서버의 /chat 으로 들어오는 post 방식 요청을 처리하는 chat_post() 함수를 엔드포인트로 등록
@app.route ( "/chat" , methods=[ "POST" ])
def chat_post():
 
# post 방식의 요청 파라미터를 읽어온다.
    print( "methods : " , request.method)
    req_param={}
    req_param[ "one" ] = request.form.get( "one" )
    req_param[ "two" ] = request.form.get( "two" )
    req_param[ "three" ] = request.form.get( "three" )
    req_param[ "four" ] = request.form.get( "four" )
    req_param[ "five" ] = request.form.get( "five" )
    req_param[ "type_st" ] = request.form.get( "type_st" )
# 웹 서버 콘솔에 출력
    print( "req_param : " , req_param)
# 템플릿 페이지(뷰 페이지)를 반환하면서 모델 정보를 인수로 지정할 수 있다.
# chat_get() 함수에서 사용했던 가변인수 방식과 동일하게 동작한다.
# 템플릿으로 보내야 하는 모델 데이터가 많을 경우 유용하게 사용할 수 있다.
    return render_template( "rank.html" , **req_param)
# 서버의 /chatting 으로 들어오는 post 방식 요청을 처리하는 함수를 엔드포인트로 등록
@app.route ( "/chatting" , methods=[ "POST" ])

    
def chatting():
    pass
# 사전 데이터를 JSON 형식으로 변환해 반환할 수 있음
#return jsonify({"msg": req_msg})


# 현재 모듈이 main으로 실행되면 웹 서비스를 시작한다.
if __name__ ==  "__main__" :
# host 옵션을 생략하거나 "localhost"로 지정하면 현재 모듈을 로컬 서버로 실행한다.
# host를 아래와 같이 "0.0.0.0"으로 지정하면 다른 컴퓨터에서 접근가능하다.
    app.run(host= "0.0.0.0" , port=9020)
# 개발 할때만 debug 옵션을 지정하고 실제 운영에서는 debug 옵션을 제거한다.
#app.run(host="0.0.0.0", port=9000, debug=True)
