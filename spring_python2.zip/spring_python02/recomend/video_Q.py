'''
Created on 2019. 10. 31.

@author: Leewg
'''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import font_manager, rc #한글이 나오도록 구성
from test.test_smtplib import sim_users
from h5py.h5d import FILL_VALUE_DEFAULT
from pandas._libs import index
font_name = font_manager.FontProperties(fname="c:/windows/Fonts/malgun.ttf").get_name()
rc('font', family=font_name)

import pymysql

def dbGetData():

    # Mysql에 DB데이터를 가져오기 
    db = pymysql.connect(host='192.168.0.27', port=3306, user='root', passwd='12345678', db='spring', charset='utf8')
    try:
        cursor = db.cursor()
        sql = "SELECT * FROM video_q" #해당되는 테이블을 가져옴.
        cursor.execute(sql)
        result = cursor.fetchall()
        
        #print(result) #가져온 테이블을 찍어봄.
        
        #가져온 데이터를 unpack, 빈 리스트로 값을 넣을 부분을 정리
        indexL=[]
        user_idL=[]
        catyq1L=[]
        catyq2L=[]
        catyq3L=[]
        catbq1L=[]
        catbq2L=[]
        catbq3L=[]
        catuq1L=[]
        catuq2L=[]
        catuq3L=[]
        catlq1L=[]
        catlq2L=[]
        catlq3L=[]
        catsq1L=[]
        catsq2L=[]
        catsq3L=[]
        
        
        #반복문을 돌려서 해당 빈 리스트에 값을 append로 저장시킴.
        for i in result: 
            index, user_id, catyq1,catyq2,catyq3,catbq1,catbq2,catbq3,catuq1,catuq2,catuq3,catlq1,catlq2,catlq3,catsq1,catsq2,catsq3=i
            indexL.append(index)
            user_idL.append(user_id)
            catyq1L.append(catyq1)
            catyq2L.append(catyq2)
            catyq3L.append(catyq3)
            catbq1L.append(catbq1)
            catbq2L.append(catbq2)
            catbq3L.append(catbq3)
            catuq1L.append(catuq1)
            catuq2L.append(catuq2)
            catuq3L.append(catuq3)
            catlq1L.append(catlq1)
            catlq2L.append(catlq2)
            catlq3L.append(catlq3)
            catsq1L.append(catsq1)
            catsq2L.append(catsq2)
            catsq3L.append(catsq3)    
    
        #리스트에 저장된 값을 확인함.    
        #print(indexL)
        #print(user_idL)
        #print(catyq1L)
        #print(catyq2L)
        #print(catyq3L)
        #print(catbq1L)
        #print(catbq2L)
        #print(catbq3L)
        #print(catuq1L)
        #print(catuq2L)
        #print(catuq3L)
        #print(catlq1L)
        #print(catlq2L)
        #print(catlq3L)
        #print(catsq1L)
        #print(catsq2L)
        #print(catsq3L)
    
        #리스트에 저장된 값을 불러, 정렬된 테이블을 생성해봄. (실제로는 jupyter notebook에선 DB를 불러올때 값이 테이블 형태를 뜀.)
        ratings=pd.DataFrame({
                "index":indexL,
                "user_id":user_idL,
                "YusansoQ1":catyq1L,
                "YusansoQ2":catyq2L,
                "YusansoQ3":catyq3L,
                "BoggeunQ1":catbq1L,
                "BoggeunQ2":catbq2L,
                "BoggeunQ3":catbq3L,
                "Upper_bodyQ1":catuq1L,
                "Upper_bodyQ2":catuq2L,
                "Upper_bodyQ3":catuq3L,
                "Lower_bodyQ1":catlq1L,
                "Lower_bodyQ2":catlq2L,
                "Lower_bodyQ3":catlq3L,
                "StretchingQ1":catsq1L,
                "StretchingQ2":catsq2L,
                "StretchingQ3":catsq3L
                
                })
        #리스트 저장된 테이블을 불러옴.
        #print(ratings)
    
        data=np.array([catyq1L, # 1번 문항
                                     catyq2L, # 2번 문항
                                     catyq3L, # 3번 문항
                                     catbq1L, # 4번 문항
                                     catbq2L, # 5번 문항
                                     catbq3L, # 6번 문항
                                     catuq1L, # 7번 문항
                                     catuq2L, # 8번 문항
                                     catuq3L, # 9번 문항
                                     catlq1L,# 10번 문항
                                     catlq2L,# 11번 문항
                                     catlq3L,# 12번 문항
                                     catsq1L,# 13번 문항
                                     catsq2L,# 14번 문항
                                     catsq3L])# 15번 문항 
        #print(data) #[리스트 문항별 점수 테이블]
        
        user_data = np.array(user_idL)
        #print("user_id:\n",user_data)
        
        #for i in user_data:
        #    if i == user_id:
        #        user_id = user_id
        #    elif i != user_id:
        #        print("id가 틀립니다")      
        #print("user_id:\n", user_id)
        index_data = np.array(indexL)
        
        #print(index_data)
        
        # user, 카테고리, 리스트에 저장된 데이터 값을 다시 정확하게 분석석하기 좋게 테이블 생성.
        df1 = pd.DataFrame(data,                        
                      index= ["YusansoQ1", "YusansoQ2", "YusansoQ3","BoggeunQ1","BoggeunQ2","BoggeunQ3", "Upper_bodyQ1","Upper_bodyQ2","Upper_bodyQ3","Lower_bodyQ1","Lower_bodyQ2","Lower_bodyQ3","StretchingQ1","StretchingQ2","StretchingQ3"], 
                      columns=user_data)
                    
                    #columns=["user1","user2","user3","user4","user5","user6","user7","user8","user9","user10","user11","user12","user13","user14","user15"])
          
        #분석하기 좋게 나열한 테이블 찍어봄.
        #print(df1)  
        
        #return df1       
        
    
    finally:
        db.close()    
    
    return df1


def pearsonRecommend(df1, userId):
    
    print("pearsonRecommend() - userId : ", userId)
    
    
    # 2. 사용자 사이의 유사도를 계산 [피어슨 상관계수 이용]
    sim_users = df1.corr(method='pearson')
    #print("피어슨_상관계수:\n",sim_users)
    
    # 2-1. [user = user 피어슨 상관계수] 사이에 사용자 유사도 히트맵 
    #plt.figure(figsize=(11,11))
    #sns.heatmap(df1.corr(method='pearson'), annot=True, fmt='.1f', cmap='RdYlGn', linewidth=5)
    #sns.set(font_scale=1)
    #plt.yticks(np.arange(1, len(df1.corr(method='pearson').index), 1), df1.corr(method='pearson').index)
    #plt.xticks(np.arange(1, len(df1.corr(method='pearson').columns), 1), df1.corr(method='pearson').columns)
    #plt.grid(False)
    #plt.xlabel("user", size=30)
    #plt.ylabel("user", size=30)
    #plt.title("Rate Matrix", size=40)
    #plt.show()
    
    
    #3. user ex) A=user1이 평가하지 않거나 자기 평점보다 낮은 카테고리 영상을 골라낸다.
    # 그러기위해 user ex) A=user1을 평점으로 Rename(이름변경)으로 고친 후에 다음단계에 낮은값 또는 None만 뽑아내자.
    rating_critic = pd.DataFrame(df1)
    rating_critic.rename(columns={userId :'video_rate'}, inplace = True) #user ex) A=user1특정유저를집어넣는것   
    #print("해당 유저 이름변경으로 추출:\n", rating_critic)
    #----------------------------------------------------------------------------------------
    # 4. user ex) A=user1이 평가하지 않은 or 자기평점보다 낮은 카테고리 영상을 뽑아낸다.
    #(부족한 부분을 뽑아냄 = 질문Q = 본인에게 필요한것)
    titles_na_critic = rating_critic.index[rating_critic.video_rate < df1[userId].mean()] #특정유저A 평점
    titles_na_critic = list(titles_na_critic.values)
    #print("해당 유저 이름변경으로 추출:\n", titles_na_critic)
    #----------------------------------------------------------------------------------------
    # 5. 원본데이터에서 위 user ex) A=user1이 안본 영상을 예측한 등급을 가져온다
    rating_t = df1.apply(titles_na_critic).reset_index()
    #print("rating_t(유저예측등급):\n",rating_t)
    
    # 6. user ex) A에 값을 구하지만, (원본데이터 평점*피어슨 상관계수 유사도) 
    #print(df1.shape) #원본데이터
    #print(sim_users[userId].shape) #피어슨 상관계수
    #sim_rating=df1.dot(sim_users[userId]) # 데이터 프레임 = 매트릭스 곱 dot => 원본데이터 평점(df1) * 피어슨 상관계수(sim_users)
    sim_rating = sim_users[userId] * df1
    #print("sim_rating계수:\n", sim_rating)
    
    #test(dot을 안쓰고 하는법)
    #test sim_rating = sim_users[userId] * df1
    #print("sim_rating퍼펙트:\n", test sim_rating)
    
    #★이 방법을 기본 바탕으로 하여 여기서부터 sim_rating(예측점수) = 데이터 프레임을 기반으로 데이터분석을 이행한다.★
    #[ 이 아래부터는 dot 매트릭스를 이용한 방법 및 기본평점을 통해 전체 유저의 예상점수를 통해 선호도와 해당유저값을 구하는 구간이다]
    
    # ===============[본론 1번 : 여러 유저 값 예상점수 순위로 선호도 결과값 뽑아내기]====================
    # 7. user ex) A=user1이 평가하지 않거나 자기 평점보다 낮은 카테고리 영상을 골라낸다.
    # 그러기위해 user ex) A=user1을 평점으로 Rename(이름변경)으로 고친 후에 다음단계에 낮은값 또는 None만 뽑아내자.
    # 단, 여기선 데이터프레임 = sim_rating(예측점수) 기반으로 이행. 예측점수 = ([df1 = (rate(평점))] * [sim_users =(similarity(피어슨 상관계수))])
    rating_critic1 = pd.DataFrame(sim_rating)
    rating_critic1.rename(columns={userId :'video_rate'}, inplace = True) #  user ex) A=user1, 특정유저를 집어넣는것  
    #print("user_base단계:\n",rating_critic1)
    
    #----------------------------------------------------------------------------------------
    # 8. user ex) A=user1이 평가하지 않은 or 자기평점보다 낮은 카테고리 영상을 뽑아낸다.
    #(자가진단 및 별점에 부족한 부분을 뽑아냄 = ex) 자가진단 질문Q1~Q15 or 별점 1~5점 척도.)
    #(user = 본인에게 필요한것 or 유사도를 통한 (별점)낮은 카테고리에 user와 user에 연관성으로 추천.)
    titles_na_critic2 = rating_critic1.index[rating_critic1.video_rate < sim_rating[userId].mean()] #특정유저A 평점
    titles_na_critic2 = list(titles_na_critic2.values)
    #print("유사도 특정항목\n:", titles_na_critic2)
    #----------------------------------------------------------------------------------------
    # 9. (유사도*평점) = 예측점수 = sim_rating 데이터에서 위 user ex) A=user1이 안본 영상 또는 낮은점수를 예측한 등급을 가져온다
    rating_tt = sim_rating.apply(titles_na_critic2).reset_index()
    #print("rating_tt:\n", rating_tt)
    
    # 10. jupyter notebook 에서는 합치는 과정이 다르기 때문에. 일부 계산을 제외했다.
    # sim_rating/similarity 작업시 카테고리별.sum()작업을 했으나 여기선 제외. 
    #print(sim_rating.shape)
    #print(sim_users.shape)
    similarity = (sim_rating/(df1)) # similarity(피어슨 상관계수) = sim_rating(평점*상관계수)/rate(평점) 
    #print("similarity 계수:\n", similarity)
    sim_rating2 = (similarity.mul(df1)) #  sim_rating 예상점수 = (원본데이터(평점) * 피어슨 상관계수)
    #print("sim_rating2 계수:\n", sim_rating2)
    predicts = ((sim_rating2)/(similarity)) #유사도=sim_rating(평점*상관계수)/similarity(피어슨상관계수)
    #print("predicts 예상데이터:\n", predicts) #= 예상평점 = 기존 평점 -> float로 sort나열할예정.
    
    
    # 11. 각 유저별 선호도를 조사함. 
    s1 = predicts # 각 유저들의 평점
    #print("각 유저들의 평점:\n:",s1)
    s2 = similarity# 각 유저들의 상관계수
    #print("각 유저들의 상관계수:\n",s2)
    s3 = (predicts * similarity)
    #print("각 유저들의 sim_rate:\n",s3)
     
    # 각 유저의 예상 점수를 구한다
    rate_temp1 = s3.sum(axis=1)
    #print("sim_rating합:\n",rate_temp1)
    rate_temp2 = s2.sum(axis=1)
    #print("sim_users합:\n",rate_temp2)
    predict_high= (rate_temp1 / rate_temp2)
    #print("★각 유저들의 상관계수를 통해 카테고리별 높은 예상점수 추천★:\n" ,predict_high)
    
    # =================[본론2번 : 해당유저 값 예상점수 순위로 최종 결과값을 뽑아내기]=================
    # 1. s3 데이터 프레임 적용
    rating_critic2 = pd.DataFrame(s3)
    rating_critic2.rename(columns={userId :'video_rate'}, inplace = True) #  user ex) A=user1, 특정유저를 집어넣는것  
    #print("user_base단계:\n",rating_critic2)
    
    # 2. user ex) A=user1이 평가하지 않은 or 자기평점보다 낮은 카테고리 영상을 뽑아낸다.
    #(자가진단 및 별점에 부족한 부분을 뽑아냄 = ex) 자가진단 질문Q1~Q15 or 별점 1~5점 척도.)
    #(user = 본인에게 필요한것 or 유사도를 통한 (별점)낮은 카테고리에 user와 user에 연관성으로 추천.)
    titles_na_critic3 = rating_critic2.index[rating_critic2.video_rate < s3[userId].mean()] #특정유저A 평점
    titles_na_critic3 = list(titles_na_critic3.values)
    #print("유사도 특정항목\n:", titles_na_critic3)
    #----------------------------------------------------------------------------------------
    # 3. s3 데이터 프레임에서 위 user 예측한 카테고리를 가져온다
    rating_ttt = s3.apply(titles_na_critic3)
    #print("해당 유저의 sim_rate 항목 결과값 = rating_ttt:\n", rating_ttt)
    # 4. s2 데이터 프레임에서 위 user 예측한 카테고리를 가져온다
    rating_tttt = s2.apply(titles_na_critic3)
    #print("해당 유저의 연관된  피어슨 상관계수 항목 결과값 = rating_tttt:\n", rating_tttt)
    
    rate_temp2 = rating_ttt.sum(axis=1)
    #print(rate_temp2)
    rate_temp3 = rating_tttt.sum(axis=1)
    #print(rate_temp3)
    predictResult = (rate_temp2 / rate_temp3).reset_index()
    predictResult.columns=["index", userId]
    #print("해당 유저의 최종 예상점수 = predict:\n", predictResult)
    #rate_temp4 = rating_ttt[userId] / rating_tttt[userId]
    #print(rate_temp4)
    predict_user= predictResult
    #print("★해당 유저의 카테고리별 예상점수★:\n" ,predict_user)
    
    # 12. 최종적으로 해당 유저 user ex) A=user1의 예상 추천 카테고리를 순위별로 나열하여 구한다. 
    #이외에 평점 평균 또는 유저들이 선호하는 카테고리 영상 순위별로 나열하여 구한다.
    result = predict_user.sort_values(by=userId, axis=0, ascending=True)                
    result2 = predict_high.sort_values(axis=0, ascending=False)
    result3 = df1.mean()
    
    print("------------------------[해당 user Daily 자가진단 필요운동 순위]-----------------------------")
    print("해당유저가 필요한 영상 순위별 최종데이터:\n", result)
    print("-------[각 유저들의 상관계수를 통해 해당 유저의 카테고리별 높은 예상점수는 충족하는 운동부분]-------------")
    print("여러유저의 선호도 데이터:\n", result2)
    print("------------------------[user간의  Daily 평균 진단점수 ]-----------------------------------")
    print("유저별 자가진단 평균데이터:\n", result3)
    
    return result


if __name__ == "__main__":
    
    dbDf1 = dbGetData()
    
    recom = pearsonRecommend(dbDf1, "yujin")
    print("recommend 해당 유저가 필요한 운동은 평점3점 미만 중에서 최상위 top3~5:\n", recom)
