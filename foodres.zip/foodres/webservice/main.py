'''
Created on 2019. 10. 31.

@author: inc-019
'''
#flask �쎒 �봽�젅�엫�썙�겕 �궗�슜
from flask import Flask, render_template, request, redirect, jsonify, Response, make_response

from webservice.db.db_connector import MySqlDbConnector
from webservice.db.value_object import  eatedinfo
from webservice.python.getDataframe import getStdDataframe, getPersonEatedList, getNutrientList, getRecommandList, getOneStdDataframe


app=Flask(__name__)

@app.route("/")
def home():
    
 
    method=request.args.get("method")
    print("home()-method:",method)
    
  
    print("methods:",request.method)
    
  
    return render_template("index.html",method=method)



# 파라미터 받아서 spring DB eatedinfo table에 추가한다 
def addeatedList(Onelist):
    dao=MySqlDbConnector("localhost","root","12345678","spring")
    dao.addEatedinfo(Onelist)
    print("foodreslist-inserted")


# 회원이 같은날짜에 이전에 등록한 행이 있으면 제거하기     
def removeOverlap(Onelist):
    dao=MySqlDbConnector("localhost","root","12345678","spring")
    dao.removeOverlap(Onelist)
    
    print("overlapped-removed")
        


# 192.168.0.31:9000/foodres로 들어올경우  
@app.route("/foodres",methods=["POST","GET"])
def foodres():    
    print("methods:",request.method)
    
    #받은 파라미터를 onelist라는 tuple로 묶어준다 
    Onelist=eatedinfo(                
                no=None,
                regDate=None,
                rdate=None,
                rtime=None,
                userId=request.form.get("userId"),
                bday=request.form.get("bday"),
                sex=request.form.get("sex"),
                height=request.form.get("height"),
                weight=request.form.get("weight"),
                paStage=request.form.get("paStage"),
                bf1=request.form.get("bf1"),
                bf1g=request.form.get("bf1amount"),
                bf2=request.form.get("bf2"),
                bf2g=request.form.get("bf2amount"),
                bf3=request.form.get("bf3"),
                bf3g=request.form.get("bf3amount"),
                lc1=request.form.get("lc1"),
                lc1g=request.form.get("lc1amount"),
                lc2=request.form.get("lc2"),
                lc2g=request.form.get("lc2amount"),
                lc3=request.form.get("lc3"),
                lc3g=request.form.get("lc3amount"),
                dn1=request.form.get("dn1"),
                dn1g=request.form.get("dn1amount"),
                dn2=request.form.get("dn2"),
                dn2g=request.form.get("dn2amount"),
                dn3=request.form.get("dn3"),
                dn3g=request.form.get("dn3amount"),
                totalK=request.form.get("totalK"),
                totalC=request.form.get("totalC"),
                totalP=request.form.get("totalP"),
                totalF=request.form.get("totalF")               
                )

                
      

     # 넘어온 파라미터 값 확인 
    print(type(Onelist.totalK),"-",Onelist.totalK) 
    
    addeatedList(Onelist)
    #removeOverlap(Onelist)
    #eatedinfo list에서 행을 입력한 회원에 대한 정보만 eatedinfo에서 조회해온다 
    # DB연결객체 변수 정의 
    dao=MySqlDbConnector("localhost","root","12345678","spring")    
    # 회원이 입력한 식단 정보 DB에 넣은 이후 , DB eatedinfo에서 userId가 해당 회원인 경우를 조회한 정보 
    rawData=dao.getEatedList(Onelist.getUserId())
    
    
    # DB연결객체 변수 정의 
    dao=MySqlDbConnector("localhost","root","12345678","spring")    
    # 회원이 방금 입력한 식단 DB에서 가져오기 
    OnerawData=dao.getEatedOneList(Onelist.getUserId())
   # 회원이 방금 입력한 식단 가져오기 
    EatedList=getPersonEatedList(OnerawData)
    regDate=EatedList["regDate"].tolist()
    userId=EatedList["userId"].tolist()
    bf1=EatedList["bf1"].tolist()
    bf1g=EatedList["bf1g"].tolist()
    bf2=EatedList["bf2"].tolist()
    bf2g=EatedList["bf2g"].tolist()
    bf3=EatedList["bf3"].tolist()
    bf3g=EatedList["bf3g"].tolist()
    lc1=EatedList["lc1"].tolist()
    lc1g=EatedList["lc1g"].tolist()
    lc2=EatedList["lc2"].tolist()
    lc2g=EatedList["lc2g"].tolist()
    lc3=EatedList["lc3"].tolist()
    lc3g=EatedList["lc3g"].tolist()
    dn1=EatedList["dn1"].tolist()
    dn1g=EatedList["dn1g"].tolist()
    dn2=EatedList["dn2"].tolist()
    dn2g=EatedList["dn2g"].tolist()
    dn3=EatedList["dn3"].tolist()
    dn3g=EatedList["dn3g"].tolist()

    
    # 회원이 입력한 식단으로 전처리한 영양정보 가져오기
    OneNutrientList=getNutrientList(rawData)
    rdate=OneNutrientList["rdate"].tolist()
    EER=OneNutrientList["EER"].tolist()
    EERC=OneNutrientList["EERC"].tolist()
    EERP=OneNutrientList["EERP"].tolist()
    EERF=OneNutrientList["EERF"].tolist()
    totalK=OneNutrientList["totalK"].tolist()
    totalC=OneNutrientList["totalC"].tolist()
    totalP=OneNutrientList["totalP"].tolist()
    totalF=OneNutrientList["totalF"].tolist()
    
    recommand=getRecommandList(OnerawData)
    ffoodname=recommand["foodname"].tolist()
    fserving=recommand["serving"].tolist()
    fkcal=recommand["kcal"].tolist()
    fcar=recommand["car"].tolist()
    fpro=recommand["pro"].tolist()
    ffat=recommand["fat"].tolist()
    fsugars=recommand["sugars"].tolist()
    fsalt=recommand["salt"].tolist()
    fcholesterol=recommand["cholesterol"].tolist()
    fsfacid=recommand["sfacid"].tolist()
    ftfacid=recommand["tfacid"].tolist()
    
    res = Response()
    res.headers.add("Access-Control-Allow-Origin", "*")
    res.set_data(render_template("foodres.html", regDate=regDate,userId=userId,bf1=bf1,bf1g=bf1g,bf2=bf2,bf2g=bf2g,
    bf3=bf3,bf3g=bf3g,lc1=lc1,lc1g=lc1g,lc2=lc2,lc2g=lc2g,lc3=lc3,lc3g=lc3g,dn1=dn1,dn1g=dn1g,dn2=dn2,dn2g=dn2g,
    dn3=dn3,dn3g=dn3g,rdate=rdate,EER=EER,EERC=EERC,EERP=EERP,EERF=EERF,totalK=totalK,totalC=totalC,totalP=totalP,totalF=totalF,
    ffoodname=ffoodname,fserving=fserving,fkcal=fkcal,fcar=fcar,fpro=fpro,ffat=ffat,fsugars=fsugars,fsalt=fsalt,
    fcholesterol=fcholesterol,fsfacid=fsfacid,ftfacid=ftfacid))
    
        
    return res   
                
        
#파라미터 들어오면 각 변수로 받아서 Onelist tuple로 묶기      
"""
                no=None,
                regDate=None,
                rdate=None,
                rtime=None,
                userId=request.form.get("userId"),
                bday=request.form.get("bday"),
                sex=request.form.get("sex"),
                height=request.form.get("height"),
                weight=request.form.get("weight"),
                paStage=request.form.get("paStage"),
                bf1=request.form.get("bf1"),
                bf1g=request.form.get("bf1amount"),
                bf2=request.form.get("bf2"),
                bf2g=request.form.get("bf2amount"),
                bf3=request.form.get("bf3"),
                bf3g=request.form.get("bf3amount"),
                lc1=request.form.get("lc1"),
                lc1g=request.form.get("lc1amount"),
                lc2=request.form.get("lc2"),
                lc2g=request.form.get("lc2amount"),
                lc3=request.form.get("lc3"),
                lc3g=request.form.get("lc3amount"),
                dn1=request.form.get("dn1"),
                dn1g=request.form.get("dn1amount"),
                dn2=request.form.get("dn2"),
                dn2g=request.form.get("dn2amount"),
                dn3=request.form.get("dn3"),
                dn3g=request.form.get("dn3amount"),
                totalK=request.form.get("totalK"),
                totalC=request.form.get("totalC"),
                totalP=request.form.get("totalP"),
                totalF=request.form.get("totalF")       
"""
"""test
                no=None,
                regDate=None,
                rdate=None,
                rtime=None,
                userId="jiwon",
                bday="19951208",
                sex="1",
                height="157",
                weight="65",
                paStage="2",
                bf1="빵",
                bf1g="200",
                bf2="빵",
                bf2g="200",
                bf3="빵",
                bf3g="200",
                lc1="빵",
                lc1g="200",
                lc2="빵",
                lc2g="200",
                lc3="밥",
                lc3g="100",
                dn1="밥",
                dn1g="100",
                dn2="밥",
                dn2g="100",
                dn3="밥",
                dn3g="100",
                totalK="2600",
                totalC="1400",
                totalP="50",
                totalF="240"       

"""                 
    




if __name__=="__main__":
    
    
    app.run(host="0.0.0.0",port=9000, debug=True)
    
   
        
        
        
        

    