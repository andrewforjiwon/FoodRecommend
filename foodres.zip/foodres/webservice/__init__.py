'''
Created on 2019. 10. 31.

@author: inc-019
'''
#flask 웹 프레임워크 사용
from flask import Flask, render_template,request, jsonify, Response, make_response



#flask 객체생성 
app=Flask(__name__)

# Flask(app)가 제공하는 route 데코레이터(decorator)를 사용해 
# 서버의 루트(/)로 들어오는 요청을 처리하는 home() 함수를 엔드포인트로 등록
# SpringFramework에서 @RequestMapping과 비슷한 역할을 함
@app.route("/")
def home():
    
    # get 방식 요청 파라미터를 읽어온다. 지정한 요청 파라미터가 없으면 None이 넘어온다.
    method=request.args.get("method")
    print("home()-method:",method)
    
    # 요청 방식이 GET 방식인지 POST 방식인지 다음과 같이 확인할 수 있다.
    print("methods:",request.method)
    
    # 화면에 출력할 템플릿 페이지를 반환하면서 모델 데이터를 인수로 지정할 수 있따
    # 현재 모듈이 실행되는 위치에서 templates/index.html 파일을 찾는다
    # 뷰 페이지에서 사용할 모델 데이터를 method 이름으로 같이 보낸다.
    return render_template("index.html",method=method)

# 서버의 /chat으로 들어오는 post 방식 요청을 처리하는 chat_post() 함수를 엔드포인트로 등록 
@app.route("/foodres")
def foodres():
    # post 방식의 요청 파라미터를 읽어온다.
    print("methods:",request.method)
   
    req_param={}
    req_param["no"]=request.form.get("no")
    req_param["regDate"]=request.form.get("regDate")
    req_param["userId"]=request.form.get("userId")
    req_param["bday"]=request.form.get("bday")
    req_param["sex"]=request.form.get("sex")
    req_param["height"]=request.form.get("height")
    req_param["weight"]=request.form.get("weight")
    req_param["paStage"]=request.form.get("paStage")
    req_param["bf1"]=request.form.get("bf1")
    req_param["bf2"]=request.form.get("bf2")
    req_param["bf3"]=request.form.get("bf3")
    req_param["lc1"]=request.form.get("lc1")
    req_param["lc2"]=request.form.get("lc2")
    req_param["lc3"]=request.form.get("lc3")
    req_param["dn1"]=request.form.get("dn1")
    req_param["dn2"]=request.form.get("dn2")
    req_param["dn3"]=request.form.get("dn3")
    req_param["totalK"]=request.form.get("totalK")
    req_param["totalC"]=request.form.get("totalC")
    req_param["totalP"]=request.form.get("totalP")
    req_param["totalF"]=request.form.get("totalF")
    req_param["pass1"]=request.form.get("pass1")
 
    req_param["minho"] = "민호의 훗음 하하하"   
    # list 보내주면  ArrayList<Member>
    """  
    while(r
    s.next()) {
        add()
    }    
    
    """
    
    # 웹 서버 콘솔에 출력 
    print("req_param:",req_param)
    
    res = Response()
    res.headers.add("Access-Control-Allow-Origin", "*")
    res.set_data(render_template("foodres.html",**req_param))
    
    return res
    # 템플릿 페이지(뷰 페이지)를 반환하면서 모델 정보를 인수로 저장할 수 잇다.
    # chat_get() 함수에서 사용했던 가변인수 방식과 동일하게 동작한다 
    # 템플릿으로 보내야하는 모델 데이터가 많을 경우 유용하게 사용할 수 있다. 
    #return render_template("foodres.html",**req_param)

#서버의 /chatting으로 들어오는 post 방식 요청을 처리하는 함수를 엔드포인트로 등록 
"""
@app.route("/foodres",methods=["POST"])
def chatting():
    req_msg=request.form.get("req_msg")
    print("req_msg:",req_msg)
    
    return req_msg
    # 사전 데이터를 JSON 형식으로 변환해 반환할 수 있음 
    #return jsonify({"msg":req_msg})
"""    
# 현재 모듈이 main으로 실행되면 웹 서비스를 시작한다 
if __name__=="__main__":
    
    # host 옵션을 생략하거나 "localhost"로 지정하면 현재 모듈을 로컬 서버로 실행한다 
    # host를 아래와 같이 "0.0.0.0"으로 지정하면 다른 컴퓨터에서 접근가능하다 
    app.run(host="0.0.0.0",port=9000, debug=True)
    
    # 개발 할 때만 debug 옵션을 지정하고 실제 운영에서는 debug 옵션을 제거한다.
    #app.run(host="0.0.0.0", port=9000, debug=True)
        
        
        