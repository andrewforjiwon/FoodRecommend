'''
Created on 2019. 10. 29.
@author: inc-1class
DB Connecting 모듈

먼저 SQL 패키지에 있는 member.sql을 이용해 DB 스키마를 생성하고
회원 정보에 대한 데이터를 추가한다.  

그리고 pymysql 패키지를 아래와 같이 설치한다.
pip3 install pymysql

flask DB 연동 참고 사이트 
https://www.fun-coding.org/flask_basic-3.html


'''
import pymysql
from webservice.db.value_object import eatedinfo
from webservice.db.value_object_food import foodinfo

class MySqlDbConnector:
    
    def __init__(self, host, user, pw, db):
        
        # pymysql을 이용해 DB에 접속
        self.conn = pymysql.connect(
            host=host, user=user, password=pw, db=db, charset="utf8")
    

    def getfoodList(self):
        
        foodList = []
        
        
       
        try:
            # DB 접속 객체로 부터 커서 객체를 구함
            with self.conn.cursor() as cursor:
                
                sql = "SELECT * FROM foodList"
                
                # 쿼리를 DB에 발행
                cursor.execute(sql)
                
                # DB로 부터 읽어오 데이터를 추출(각 행 tuple로 반환됨)
                # 각 tuple을 eatedList에 묶어서 return시킴 
        
                rows = cursor.fetchall()
 
                for row in rows:
                          
                    r = foodinfo(no=row[0], classification=row[1], foodname=row[2], 
                            serving=row[3], kcal=row[4], car=row[5], pro=row[6],
                            fat=row[7], sugars=row[8],salt=row[9],
                            cholesterol=row[10],sfacid=row[11],tfacid=row[12])
                    
                                     
                    foodList.append(r)
                    
                # 먹은 리스트 반환 
                return foodList
                print("foodList-length:",len(foodList))
                   
            
        finally:
            # DB 연결 종료
            self.conn.close()
    
     
    def getEatedList(self,userId):
        
        eatedList = []
        
        
       
        try:
            # DB 접속 객체로 부터 커서 객체를 구함
            with self.conn.cursor() as cursor:
                
                sql = "SELECT * FROM eatedinfo where user_id=%s"
                
                # 쿼리를 DB에 발행
                cursor.execute(sql, userId)
                
                # DB로 부터 읽어오 데이터를 추출(각 행 tuple로 반환됨)
                # 각 tuple을 eatedList에 묶어서 return시킴 
        
                rows = cursor.fetchall()
 
                for row in rows:
                          
                    r = eatedinfo(no=row[0], regDate=row[1], rdate=row[2], 
                            rtime=row[3],userId=row[4], bday=row[5], sex=row[6],
                            height=row[7],weight=row[8],paStage=row[9],
                            bf1=row[10],bf1g=row[11],bf2=row[12],bf2g=row[13],bf3=row[14],bf3g=row[15],
                            lc1=row[16], lc1g=row[17], lc2=row[18],lc2g=row[19],lc3=row[20],lc3g=row[21],
                            dn1=row[22],dn1g=row[23],dn2=row[24],dn2g=row[25],dn3=row[26],dn3g=row[27],
                            totalK=row[28],totalC=row[29],totalP=row[30],totalF=row[31])
                    
                                     
                    eatedList.append(r)
                    
                # 먹은 리스트 반환 
                return eatedList
                print("eatedList-length:",len(eatedList))
                   
            
        finally:
            # DB 연결 종료
            self.conn.close()
            
        
        
    def getEatedOneList(self,userId):
        
        eatedOneList = []
        
        
        
        try:
            # DB 접속 객체로 부터 커서 객체를 구함
            with self.conn.cursor() as cursor:
                
                sql = "SELECT * FROM eatedinfo WHERE user_id=%s order by reg_date DESC limit 1"
                
                # 쿼리를 DB에 발행
                cursor.execute(sql, userId)
                
                # DB로 부터 읽어오 데이터를 추출(각 행 tuple로 반환됨)
                # 각 tuple을 eatedList에 묶어서 return시킴 
        
                rows = cursor.fetchall()
 
                for row in rows:
                          
                    r = eatedinfo(no=row[0], regDate=row[1], rdate=row[2], 
                            rtime=row[3],userId=row[4], bday=row[5], sex=row[6], height=row[7], weight=row[8],paStage=row[9],
                            bf1=row[10],bf1g=row[11],bf2=row[12],bf2g=row[13],bf3=row[14],bf3g=row[15],
                            lc1=row[16], lc1g=row[17], lc2=row[18],lc2g=row[19],lc3=row[20],lc3g=row[21],
                            dn1=row[22],dn1g=row[23],dn2=row[24],dn2g=row[25],dn3=row[26],dn3g=row[27],
                            totalK=row[28],totalC=row[29],totalP=row[30],totalF=row[31])
                    
                                     
                    eatedOneList.append(r)
                    
                # 먹은 리스트 반환 
                return eatedOneList
                print("eatedList-length:",len(eatedOneList))
                   
         
        finally:
            # DB 연결 종료
            self.conn.close()     
    
    
    # 한사람이 먹은 식단을 입력한 한 행이 onelist로 넘어오면 springDB에 eatedinfo 테이블에 넣는다  
    def addEatedinfo(self,onelist):
        
        try:
            # DB 접속 객체로 부터 커서 객체를 구함
            with self.conn.cursor() as cursor:
                
                sql = """
                   INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
                                VALUES (SYSDATE(),substr(SYSDATE(),1,10),substr(SYSDATE(),12,9),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);

                    """
                
                # 쿼리를 DB에 발행
                cursor.execute(sql, (onelist.getUserId(),\
                                     onelist.getBday(),\
                                     onelist.getSex(),\
                                     onelist.getHeight(),\
                                     onelist.getWeight(),\
                                     onelist.getPaStage(),\
                                     onelist.getBf1(),\
                                     onelist.getBf1g(),\
                                     onelist.getBf2(),\
                                     onelist.getBf2g(),\
                                     onelist.getBf3(),\
                                     onelist.getBf3g(),\
                                     onelist.getLc1(),\
                                     onelist.getLc1g(),\
                                     onelist.getLc2(),\
                                     onelist.getLc2g(),\
                                     onelist.getLc3(),\
                                     onelist.getLc3g(),\
                                     onelist.getDn1(),\
                                     onelist.getDn1g(),\
                                     onelist.getDn2(),\
                                     onelist.getDn2g(),\
                                     onelist.getDn3(),\
                                     onelist.getDn3g(),\
                                     onelist.getTotalK(),\
                                     onelist.getTotalC(),\
                                     onelist.getTotalP(),\
                                     onelist.getTotalF()))        
                
                # DB 파일에 적용
                self.conn.commit()
                return onelist
        finally:
            # DB 연결 종료
            self.conn.close()
        
            print(onelist.getUserId(), "- 회원 등록 완료")
            # 여기까지 행삽입       
    

    # 중복행 처리 
    def RemoveOverlap(self, onelist):
        
        try:
            # DB 접속 객체로 부터 커서 객체를 구함
            with self.conn.cursor() as cursor:    
                sql = """
                   DELETE FROM eatedinfo 
                                WHERE user_id==%s, rdate==%s, rtime<=%s   
                    """
                            
                # 쿼리를 DB에 발행
                cursor.execute(sql, (
                                     onelist.getUserId(),\
                                     onelist.getReg_date().split(' ',2)[0],
                                     onelist.getReg_date().split(' ',2)[1]
                                     )
                    )
                # DB 파일에 적용
                self.conn.commit()
            print(onelist.getReg_date().split(' ',2)[0],"--date")
            print(onelist.getReg_date().split(' ',2)[1],"--time")
               
        finally:
            # DB 연결 종료
            self.conn.close()
            print(onelist.getUserId(), "- 중복일정제거")
