'''
Created on 2019. 10. 29.
@author: inc-1class
VO(Value Object) 클래스를 정의하는 모듈)
'''

class eatedinfo:
    
     
    def __init__(self, *args, **kwargs):
        
        self.no=kwargs["no"]
        self.regDate=kwargs["regDate"]
        self.rdate=kwargs["rdate"]
        self.rtime=kwargs["rtime"]
        self.userId=kwargs["userId"]
        self.bday=kwargs["bday"]
        self.sex=kwargs["sex"]
        self.height=kwargs["height"]
        self.weight=kwargs["weight"]
        self.paStage=kwargs["paStage"]
        self.bf1=kwargs["bf1"]
        self.bf1g=kwargs["bf1g"]
        self.bf2=kwargs["bf2"]
        self.bf2g=kwargs["bf2g"]
        self.bf3=kwargs["bf3"]
        self.bf3g=kwargs["bf3g"]
        self.lc1=kwargs["lc1"]
        self.lc1g=kwargs["lc1g"]
        self.lc2=kwargs["lc2"]
        self.lc2g=kwargs["lc2g"]
        self.lc3=kwargs["lc3"]
        self.lc3g=kwargs["lc3g"]
        self.dn1=kwargs["dn1"]
        self.dn1g=kwargs["dn1g"]
        self.dn2=kwargs["dn2"]
        self.dn2g=kwargs["dn2g"]
        self.dn3=kwargs["dn3"]
        self.dn3g=kwargs["dn3g"]
        self.totalK=kwargs["totalK"]
        self.totalC=kwargs["totalC"]
        self.totalP=kwargs["totalP"]
        self.totalF=kwargs["totalF"]

    def getRdate(self):
        return self.rdate
    def setRdate(self,rdate):
        self.rdate=rdate
   
    def getRtime(self):
        return self.rtime
    def setRtime(self,rtime):
        self.rtime=rtime
    
    def getNo(self):
        return self.no
    def setNo(self, no):
        self.no = no
        
    def getReg_date(self):
        return self.regDate
    def setReg_date(self,regDate):
        self.reg_date=regDate
    
    def getUserId(self):
        return self.userId
    def setUserId(self,userId):
        self.userId=userId
   
    def getBday(self):
        return self.bday
    def setBday(self, bday):
        self.bday=bday
    
    def getSex(self):
        return self.sex
    def setSex(self, sex):
        self.sex = sex
    
    def getHeight(self):
        return self.height
    def setHeight(self, height):
        self.height=height
    
    def getWeight(self):
        return self.weight
    def setWeight(self, weight):
        self.weight=weight
    
    def getPaStage(self):
        return self.paStage
    def setPaStage(self, PaStage):
        self.PaStage=PaStage
    
    def getBf1(self):
        return self.bf1
    def setBf1(self, bf1):
        self.bf1=bf1
    def getBf1g(self):
        return self.bf1g
    def setBf1g(self, bf1g):
        self.bf1g=bf1g
        
    def getBf2(self):
        return self.bf2
    def setBf2(self, bf2):
        self.bf2=bf2
    def getBf2g(self):
        return self.bf2g
    def setBf2g(self, bf2g):
        self.bf2g=bf2g
    
    def getBf3(self):
        return self.bf3
    def setBf3(self, bf3):
        self.bf3=bf3
    def getBf3g(self):
        return self.bf3g
    def setBf3g(self, bf3g):
        self.bf3g=bf3g
    
    
    def getLc1(self):
        return self.lc1
    def setLc1(self, lc1):
        self.lc1=lc1
    def getLc1g(self):
        return self.lc1g
    def setLc1g(self, lc1g):
        self.lc1g=lc1g
        
    def getLc2(self):
        return self.lc2
    def setLc2(self, lc2):
        self.lc2=lc2
    def getLc2g(self):
        return self.lc2g
    def setLc2g(self, lc2g):
        self.lc2g=lc2g
        
    def getLc3(self):
        return self.lc3
    def setLc3(self, lc3):
        self.lc3=lc3
    def getLc3g(self):
        return self.lc3g
    def setLc3g(self, lc3g):
        self.lc3g=lc3g  
          
    def getDn1(self):
        return self.dn1
    def setDn1(self, dn1):
        self.dn1=dn1
    def getDn1g(self):
        return self.dn1g
    def setDn1g(self, dn1g):
        self.dn1g=dn1g

    def getDn2(self):
        return self.dn2
    def setDn2(self, dn2):
        self.dn2=dn2
    def getDn2g(self):
        return self.dn2g
    def setDn2g(self, dn2g):
        self.dn2g=dn2g

    def getDn3(self):
        return self.dn3
    def setDn3(self, dn3):
        self.dn3=dn3
    def getDn3g(self):
        return self.dn3g
    def setDn3g(self, dn3g):
        self.dn3g=dn3g
        
    def getTotalK(self):
        return self.totalK
    def setTotalK(self, totalK):
        self.totalK=totalK
    
    def getTotalC(self):
        return self.totalC
    def setTotalC(self, totalC):
        self.totalC=totalC
    
    def getTotalP(self):
        return self.totalP
    def setTotalP(self, totalP):
        self.totalP=totalP
    
    def getTotalF(self):
        return self.totalF
    def setTotalF(self, totalF):
        self.totalC=totalF
        
        