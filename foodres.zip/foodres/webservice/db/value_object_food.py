'''
Created on 2019. 11. 4.

@author: inc-019
'''
class foodinfo:
   
    def __init__(self, *args, **kwargs):
       self.no=kwargs["no"] 
       self.classification=kwargs["classification"]
       self.foodname=kwargs["foodname"]
       self.serving=kwargs["serving"]
       self.kcal=kwargs["kcal"]
       self.car=kwargs["car"]
       self.pro=kwargs["pro"]
       self.fat=kwargs["fat"]
       self.sugars=kwargs["sugars"]
       self.salt=kwargs["salt"]
       self.cholesterol=kwargs["cholesterol"]
       self.sfacid=kwargs["sfacid"]
       self.tfacid=kwargs["tfacid"]
    
    def getNo(self):
        return self.no
    def setNo(self,no):
        self.no=no
   
    def getClassification(self):
        return self.classification
    def setClassification(self,classification):
        self.classification=classification
    
    def getFoodname(self):
        return self.foodname
    def setFoodname(self,foodname):
        self.foodname=foodname
   
    def getServing(self):
        return self.serving
    def setServing(self,serving):
        self.serving=serving
        
    def getKcal(self):
        return self.kcal
    def setKcal(self,kcal):
        self.kcal=kcal
    
    def getCar(self):
        return self.car
    def setCar(self,car):
        self.car=car
    
    def getPro(self):
        return self.pro
    def setPro(self,pro):
        self.pro=pro

    def getFat(self):
        return self.fat
    def setFat(self,fat):
        self.fat=fat
    
    def getSugars(self):
        return self.sugars
    def setSugars(self,sugars):
        self.sugars=sugars
    
    def getSalt(self):
        return self.salt
    def setSalt(self,salt):
        self.salt=salt
    
    def getCholesterol(self):
        return self.cholesterol
    def setCholesterol(self,cholesterol):
        self.cholesterol=cholesterol
    
    def getSfacid(self):
        return self.sfacid
    def setSfacid(self,sfacid):
        self.sfacid=sfacid
    
    def getTfacid(self):
        return self.tfacid
    def setTfacid(self,tfacid):
        self.tfacid=tfacid
        
    
                