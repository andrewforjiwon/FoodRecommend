'''
Created on 2019. 11. 2.

@author: 오지원
'''
import pandas as pd 

from webservice.db.db_connector import MySqlDbConnector
from pandas.tests.scalar import timestamp
from scipy.constants.constants import carat
import datetime


def getFoodRawList():
    dao=MySqlDbConnector("localhost","root","12345678","spring")
    foodlist=dao.getfoodList()
    no=[]
    classification=[]
    foodname=[]
    serving=[]
    kcal=[]
    car=[]
    pro=[]
    fat=[]
    sugars=[]
    salt=[]
    cholesterol=[]
    sfacid=[]
    tfacid=[]
    
    for i in range(0,len(foodlist)):
        no.append(foodlist[i].no)
        classification.append(foodlist[i].classification)
        foodname.append(foodlist[i].foodname)
        serving.append(foodlist[i].serving)
        kcal.append(foodlist[i].kcal)
        car.append(foodlist[i].car)
        pro.append(foodlist[i].pro)
        fat.append(foodlist[i].fat)
        sugars.append(foodlist[i].sugars)
        salt.append(foodlist[i].salt)
        cholesterol.append(foodlist[i].cholesterol)
        sfacid.append(foodlist[i].sfacid)
        tfacid.append(foodlist[i].tfacid)
    
    foodRawList=pd.DataFrame({
        "foodname":foodname,
        "serving":serving,
        "kcal":kcal,
        "car":car,
        "pro":pro,
        "fat":fat,
        "sugars":sugars,
        "salt":salt,
        "cholesterol":cholesterol,
        "sfacid":sfacid,
        "tfacid":tfacid
        })
    return foodRawList
    

def getFoodList():
    dao=MySqlDbConnector("localhost","root","12345678","spring")
    foodlist=dao.getfoodList()
    no=[]
    classification=[]
    foodname=[]
    serving=[]
    kcal=[]
    car=[]
    pro=[]
    fat=[]
    sugars=[]
    salt=[]
    cholesterol=[]
    sfacid=[]
    tfacid=[]
    
    for i in range(0,len(foodlist)):
        no.append(foodlist[i].no)
        classification.append(foodlist[i].classification)
        foodname.append(foodlist[i].foodname)
        serving.append(foodlist[i].serving)
        kcal.append(foodlist[i].kcal)
        car.append(foodlist[i].car)
        pro.append(foodlist[i].pro)
        fat.append(foodlist[i].fat)
        sugars.append(foodlist[i].sugars)
        salt.append(foodlist[i].salt)
        cholesterol.append(foodlist[i].cholesterol)
        sfacid.append(foodlist[i].sfacid)
        tfacid.append(foodlist[i].tfacid)
    
    uC=[]
    uP=[]
    uF=[]
    for i in range(0,len(foodlist)):
        uCi=serving[i]/100*car[i]    
        uC.append(uCi)
        uPi=serving[i]/100*pro[i]    
        uP.append(uPi)
        uFi=serving[i]/100*fat[i]    
        uF.append(uFi)
    
    food_CFratio=[]
    food_CPratio=[]
    food_FPratio=[]
    for i in range(0,len(foodlist)):
        if uF[i]==0: 
            food_CFratioi=0
            food_CFratio.append(food_CFratioi)
        else: 
            food_CFratioi=uC[i]/uF[i]
            food_CFratio.append(food_CFratioi)
        if  uP[i]==0:
            food_CPratioi=0
            food_CPratio.append(food_CPratioi)
            food_FPratioi=0
            food_FPratio.append(food_FPratioi)
        else: 
            food_CPratioi=uC[i]/uP[i]
            food_CPratio.append(food_CPratioi)
            food_FPratioi=uF[i]/uP[i]
            food_FPratio.append(food_FPratioi)
            
    #print("foodname:",len(foodname))
    #print("len(uC):",len(uC))
    #print("len(uP):",len(uP))
    #print("len(uF):",len(uF))
    #print("food_CFratio:",len(food_CFratio))
    #print("food_CPratio:",len(food_CPratio))
    #print("food_FPratio:",len(food_FPratio))
    
    foodlist=pd.DataFrame({
        "foodname":foodname,
        "uC":uC,
        "uP":uP,
        "uF":uF,
        "food_CFratio":food_CFratio,
        "food_CPratio":food_CPratio,
        "food_FPratio":food_FPratio
        })
    #print("foodlist:\n",foodlist)
    return foodlist
    
        
       
def getStdDataframe(rawdata):
    #list로 쓸지 모르니 일단 둔다 
    no=[]
    regDate=[]
    rdate=[]
    rtime=[]
    userId=[]
    bday=[]
    sex=[]
    height=[]
    weight=[]
    paStage=[]
    bf1=[]
    bf1g=[]
    bf2=[]
    bf2g=[]
    bf3=[]
    bf3g=[]
    lc1=[]
    lc1g=[]
    lc2=[]
    lc2g=[]
    lc3=[]
    lc3g=[]
    dn1=[]
    dn1g=[]
    dn2=[]
    dn2g=[]
    dn3=[]
    dn3g=[]
    totalK=[]
    totalC=[]
    totalP=[]
    totalF=[]  
    for i in range(0,len(rawdata)):
        no.append(rawdata[i].no)
        regDate.append(rawdata[i].regDate)
        rdate.append(rawdata[i].rdate)
        rtime.append(rawdata[i].rtime)
        userId.append(rawdata[i].userId)
        bday.append(rawdata[i].bday)
        sex.append(rawdata[i].sex)
        height.append(rawdata[i].height)
        weight.append(rawdata[i].weight)
        paStage.append(rawdata[i].paStage)
        bf1.append(rawdata[i].bf1)
        bf1g.append(rawdata[i].bf1g)
        bf2.append(rawdata[i].bf2)
        bf2g.append(rawdata[i].bf2g)
        bf3.append(rawdata[i].bf3)
        bf3g.append(rawdata[i].bf3g)
        lc1.append(rawdata[i].lc1)
        lc1g.append(rawdata[i].lc1g)
        lc2.append(rawdata[i].lc2)
        lc2g.append(rawdata[i].lc2g)
        lc3.append(rawdata[i].lc3)
        lc3g.append(rawdata[i].lc3g)
        dn1.append(rawdata[i].dn1)
        dn1g.append(rawdata[i].dn1g)
        dn2.append(rawdata[i].dn2)
        dn2g.append(rawdata[i].dn2g)
        dn3.append(rawdata[i].dn3)
        dn3g.append(rawdata[i].dn3g)
        totalK.append(float(rawdata[i].totalK))
        totalC.append(float(rawdata[i].totalC))
        totalP.append(float(rawdata[i].totalP))
        totalF.append(float(rawdata[i].totalF))
    
    rawData=pd.DataFrame({"no":no,"regDate":regDate,"rdate":rdate, "rtime":rtime, "userId":userId,"bday":bday,"sex":sex,
                          "height":height,"weight":weight,"paStage":paStage,"bf1":bf1,"bf1g":bf1g,"bf2":bf2,"bf2g":bf2g,
                          "bf3":bf3,"bf3g":bf3g,"lc1":lc1,"lc1g":lc1g,"lc2":lc2,"lc2g":lc2g,"lc3":lc3,"lc3g":lc3g,
                          "dn1":dn1,"dn1g":dn1g,"dn2":dn2,"dn2g":dn2g,"dn3":dn3,"dn3g":dn3g,
                          "totalK":totalK,"totalC":totalC,"totalP":totalP,"totalF":totalF})
    
    print(" rawData:\n",rawData)
    return rawData

# 음식 추천에 필요함: userId date time 일일권장섭취율(EER) 일일탄(EERC) 일일단(EERP) 일일지(EERF) totalK totalC totalP totalF
def getOneStdDataframe(Onerawdata): 
    no=[]
    regDate=[]
    rdate=[]
    rtime=[]
    userId=[]
    bday=[]
    sex=[]
    height=[]
    weight=[]
    paStage=[]
    bf1=[]
    bf1g=[]
    bf2=[]
    bf2g=[]
    bf3=[]
    bf3g=[]
    lc1=[]
    lc1g=[]
    lc2=[]
    lc2g=[]
    lc3=[]
    lc3g=[]
    dn1=[]
    dn1g=[]
    dn2=[]
    dn2g=[]
    dn3=[]
    dn3g=[]
    totalK=[]
    totalC=[]
    totalP=[]
    totalF=[]  
    for i in range(0,len(Onerawdata)):
        no.append(Onerawdata[i].no)
        regDate.append(Onerawdata[i].regDate)
        rdate.append(Onerawdata[i].rdate)
        rtime.append(Onerawdata[i].rtime)
        userId.append(Onerawdata[i].userId)
        bday.append(Onerawdata[i].bday)
        sex.append(Onerawdata[i].sex)
        height.append(Onerawdata[i].height)
        weight.append(Onerawdata[i].weight)
        paStage.append(Onerawdata[i].paStage)
        bf1.append(Onerawdata[i].bf1)
        bf1g.append(Onerawdata[i].bf1g)
        bf2.append(Onerawdata[i].bf2)
        bf2g.append(Onerawdata[i].bf2g)
        bf3.append(Onerawdata[i].bf3)
        bf3g.append(Onerawdata[i].bf3g)
        lc1.append(Onerawdata[i].lc1)
        lc1g.append(Onerawdata[i].lc1g)
        lc2.append(Onerawdata[i].lc2)
        lc2g.append(Onerawdata[i].lc2g)
        lc3.append(Onerawdata[i].lc3)
        lc3g.append(Onerawdata[i].lc3g)
        dn1.append(Onerawdata[i].dn1)
        dn1g.append(Onerawdata[i].dn1g)
        dn2.append(Onerawdata[i].dn2)
        dn2g.append(Onerawdata[i].dn2g)
        dn3.append(Onerawdata[i].dn3)
        dn3g.append(Onerawdata[i].dn3g)
        totalK.append(Onerawdata[i].totalK)
        totalC.append(float(Onerawdata[i].totalC))
        totalP.append(float(Onerawdata[i].totalP))
        totalF.append(float(Onerawdata[i].totalF))
    
    OnerawData=pd.DataFrame({"no":no,"regDate":regDate,"rdate":rdate, "rtime":rtime, "userId":userId,"bday":bday,"sex":sex,
                          "height":height,"weight":weight,"paStage":paStage,"bf1":bf1,"bf1g":bf1g,"bf2":bf2,"bf2g":bf2g,
                          "bf3":bf3,"bf3g":bf3g,"lc1":lc1,"lc1g":lc1g,"lc2":lc2,"lc2g":lc2g,"lc3":lc3,"lc3g":lc3g,
                          "dn1":dn1,"dn1g":dn1g,"dn2":dn2,"dn2g":dn2g,"dn3":dn3,"dn3g":dn3g,
                          "totalK":totalK,"totalC":totalC,"totalP":totalP,"totalF":totalF})

    return OnerawData


def getPersonEatedList(Onerawdata):
    data=getOneStdDataframe(Onerawdata)
    print("1.",data.userId[0],"님의 식단:\n")
    EatedList=pd.DataFrame(data,columns=["regDate","userId","bf1","bf1g","bf2","bf2g","bf3","bf3g","lc1","lc1g","lc2","lc2g","lc3","lc3g","dn1","dn1g","dn2","dn2g","dn3","dn3g"])
    print(EatedList)
    return EatedList

def getNutrientList(rawdata):
    age=[]
    pa=[]
    EER=[]
    EERC=[]
    EERP=[]
    EERF=[]
   
    data=getStdDataframe(rawdata)
    userId=data.userId.tolist()
    rdate=data.rdate.tolist()
    paStage=data.paStage.tolist()
    weight=data.weight.tolist()
    height=data.height.tolist()
    #print("paStage:",paStage)
    sex=data.sex.tolist()
    #print("sex:",sex)
    # 들어온 회원 나이
    for index,content in enumerate(zip(data.rdate,data.bday)): 
        agei=int(str(content[0]).split("-",1)[0])-int(str(content[1])[0]+str(content[1])[1]+str(content[1])[2]+str(content[1])[3])+1
        age.append(agei)
    #print("age:",age)
    
    # 들어온 회원 pa
    for i in data.index:
        if  paStage[i]==1 and (sex[i]=='2' and age[i]<19):
            pa.append(1)
        elif paStage[i]==2 and (sex[i]=='2' and age[i]<19):
            pa.append(1.13)
        elif paStage[i]==3 and (sex[i]=='2' and age[i]<19):
            pa.append(1.26)
        elif paStage[i]==4 and (sex[i]=='2' and age[i]<19):
            pa.append(1.42)
            
        elif paStage[i]==1 and (sex[i]=='1' and age[i]<19):
            pa.append(1.13)
        elif paStage[i]==2 and (sex[i]=='1' and age[i]<19):
            pa.append(1.16)
        elif paStage[i]==3 and (sex[i]=='1' and age[i]<19):
            pa.append(1.31)
        elif paStage[i]==4 and (sex[i]=='1' and age[i]<19):
            pa.append(1.56)
            
        elif paStage[i]==1 and (sex[i]=='2' and age[i]>=19):
            pa.append(1)
        elif paStage[i]==2 and (sex[i]=='2' and age[i]>=19):
            pa.append(1.11)
        elif paStage[i]==3 and (sex[i]=='2' and age[i]>=19):
            pa.append(1.25)
        elif paStage[i]==4 and (sex[i]=='2' and age[i]>=19):
            pa.append(1.48)
            
        elif paStage[i]==1 and (sex[i]=='1' and age[i]>=19):
            pa.append(1)
        elif paStage[i]==2 and (sex[i]=='1' and age[i]>=19):
            pa.append(1.12)
        elif paStage[i]==3 and (sex[i]=='1' and age[i]>=19):
            pa.append(1.27)
        elif paStage[i]==4 and (sex[i]=='1' and age[i]>=19):
            pa.append(1.45)
            
        else: pa.append("뭔가 잘못됨")
    #print("pa:",pa)
    
    # EER,EERC,EERP,EERF 구하기 
    for i in data.index:
        if  age[i]<19 and sex[i]=='1':
            EERi=88.5+(-61.9)*age[i]+pa[i]*((26.7*weight[i])+903*height[i]/100)
            EER.append(EERi)
            
            
        elif age[i]>=19 and sex[i]=='1':
            EERi=662+(-9.53)*age[i]+pa[i]*((15.91*weight[i])+539.6*height[i]/100)
            EER.append(EERi)
            EERCi=EERi*0.6
            EERFi=EERi*0.225
            
            EERC.append(EERCi)
            EERF.append(EERFi)
            
            if age[i]>=19 and age[i]<30:
                EERPi=65
                EERP.append(EERPi)
                
            elif age[i]>=30 and age[i]<65:
                EERPi=60
                EERP.append(EERPi)
            else:
                EERPi=55
                EERP.append(EERPi)
         
            
        elif age[i]<19 and sex[i]=='2':
            EERi=135.3+(-30.8)*age[i]+pa[i]*((10*weight[i])+934*height[i]/100)
            EER.append(EERi)
        elif age[i]>=19 and sex[i]=='2':
            EERi=354.0+(-6.91)*age[i]+pa[i]*((9.36*weight[i])+726.0*height[i]/100)
            EER.append(EERi)
    
            EERCi=EERi*0.6
            EERFi=EERi*0.225
            
            EERC.append(EERCi)
            EERF.append(EERFi)
            
            if age[i]>=19 and age[i]<30:
                EERPi=55
                EERP.append(EERPi)
                
            elif age[i]>=30 and age[i]<65:
                EERPi=50
                EERP.append(EERPi)
            else:
                EERPi=45
                EERP.append(EERPi)
        else: print("뭔가 잘못됨")
        
    totalK=data.totalK.tolist()
    totalC=data.totalC.tolist()
    totalP=data.totalP.tolist()
    totalF=data.totalF.tolist()       
    #print("EER:",EER)
    #print("EERC:",EERC)
    #print("EERP:",EERP)
    #print("EERF:",EERF)
    #print("totalK",totalK)
    #print("totalC",totalC)
    #print("totalP",totalP)
    #print("totalF",totalF)
    #print("rdate",rdate)
    
    OneNutrientList=pd.DataFrame({
        "userId":userId,
        "rdate":rdate,
        "EER":EER,
        "EERC":EERC,
        "EERP":EERP,
        "EERF":EERF,
        "totalK":totalK,
        "totalC":totalC,
        "totalP":totalP,
        "totalF":totalF
        })
    print("2. OneNutrientList:\n",OneNutrientList)
    return OneNutrientList
            
        
def getRecommandList(Onerawdata):
    age=[]
    pa=[]
    EER=[]
    EERC=[]
    EERP=[]
    EERF=[]
   
    data=getOneStdDataframe(Onerawdata)
    userId=data.userId.tolist()
    rdate=data.rdate.tolist()
    paStage=data.paStage.tolist()
    weight=data.weight.tolist()
    height=data.height.tolist()
    sex=data.sex.tolist()
    # 들어온 회원 나이
    for index,content in enumerate(zip(data.rdate,data.bday)): 
        agei=int(str(content[0]).split("-",1)[0])-int(str(content[1])[0]+str(content[1])[1]+str(content[1])[2]+str(content[1])[3])+1
        age.append(agei)
    
    # 들어온 회원 pa
    for i in data.index:
        if  paStage[i]==1 and (sex[i]=='2' and age[i]<19):
            pa.append(1)
        elif paStage[i]==2 and (sex[i]=='2' and age[i]<19):
            pa.append(1.13)
        elif paStage[i]==3 and (sex[i]=='2' and age[i]<19):
            pa.append(1.26)
        elif paStage[i]==4 and (sex[i]=='2' and age[i]<19):
            pa.append(1.42)
            
        elif paStage[i]==1 and (sex[i]=='1' and age[i]<19):
            pa.append(1.13)
        elif paStage[i]==2 and (sex[i]=='1' and age[i]<19):
            pa.append(1.16)
        elif paStage[i]==3 and (sex[i]=='1' and age[i]<19):
            pa.append(1.31)
        elif paStage[i]==4 and (sex[i]=='1' and age[i]<19):
            pa.append(1.56)
            
        elif paStage[i]==1 and (sex[i]=='2' and age[i]>=19):
            pa.append(1)
        elif paStage[i]==2 and (sex[i]=='2' and age[i]>=19):
            pa.append(1.11)
        elif paStage[i]==3 and (sex[i]=='2' and age[i]>=19):
            pa.append(1.25)
        elif paStage[i]==4 and (sex[i]=='2' and age[i]>=19):
            pa.append(1.48)
            
        elif paStage[i]==1 and (sex[i]=='1' and age[i]>=19):
            pa.append(1)
        elif paStage[i]==2 and (sex[i]=='1' and age[i]>=19):
            pa.append(1.12)
        elif paStage[i]==3 and (sex[i]=='1' and age[i]>=19):
            pa.append(1.27)
        elif paStage[i]==4 and (sex[i]=='1' and age[i]>=19):
            pa.append(1.45)
            
        else: pa.append("뭔가 잘못됨")
        
    # EER,EERC,EERP,EERF 구하기 
    for i in data.index:
        if  age[i]<19 and sex[i]=='1':
            EERi=88.5+(-61.9)*age[i]+pa[i]*((26.7*weight[i])+903*height[i]/100)
            EER.append(EERi)
            
            
        elif age[i]>=19 and sex[i]=='1':
            EERi=662+(-9.53)*age[i]+pa[i]*((15.91*weight[i])+539.6*height[i]/100)
            EER.append(EERi)
            EERCi=EERi*0.6
            EERFi=EERi*0.225
            
            EERC.append(EERCi)
            EERF.append(EERFi)
            
            if age[i]>=19 and age[i]<30:
                EERPi=65
                EERP.append(EERPi)
                
            elif age[i]>=30 and age[i]<65:
                EERPi=60
                EERP.append(EERPi)
            else:
                EERPi=55
                EERP.append(EERPi)
         
            
        elif age[i]<19 and sex[i]=='2':
            EERi=135.3+(-30.8)*age[i]+pa[i]*((10*weight[i])+934*height[i]/100)
            EER.append(EERi)
        elif age[i]>=19 and sex[i]=='2':
            EERi=354.0+(-6.91)*age[i]+pa[i]*((9.36*weight[i])+726.0*height[i]/100)
            EER.append(EERi)
    
            EERCi=EERi*0.6
            EERFi=EERi*0.225
            
            EERC.append(EERCi)
            EERF.append(EERFi)
            
            if age[i]>=19 and age[i]<30:
                EERPi=55
                EERP.append(EERPi)
                
            elif age[i]>=30 and age[i]<65:
                EERPi=50
                EERP.append(EERPi)
            else:
                EERPi=45
                EERP.append(EERPi)
        else: print("뭔가 잘못됨")
        
    totalK=data.totalK.tolist()
    totalC=data.totalC.tolist()
    totalP=data.totalP.tolist()
    totalF=data.totalF.tolist()       
    #print("EER:",EER)
    #print("EERC:",EERC)
    #print("EERP:",EERP)
    #print("EERF:",EERF)
    #print("totalK",totalK)
    #print("totalC",totalC)
    #print("totalP",totalP)
    #print("totalF",totalF)
    #print("rdate",rdate)
    
    Onestd=pd.DataFrame({
        "userId":userId,
        "rdate":rdate,
        "EER":EER,
        "EERC":EERC,
        "EERP":EERP,
        "EERF":EERF,
        "totalK":totalK,
        "totalC":totalC,
        "totalP":totalP,
        "totalF":totalF
        })
    #print("type(Onestd.EERC):\n",type(Onestd.EERC))
    #print("Onestd:\n",Onestd)
    # 한명 usercsv 추출 끝
    CLess=[]
    PLess=[]
    FLess=[]
    CFratio=[]
    CPratio=[]
    FPratio=[]
    
    for i in Onestd.index:
        CLessi=float(Onestd.EERC[i])-float(Onestd.totalC[i])
        CLess.append(CLessi)
        PLessi=float(Onestd.EERP[i])-float(Onestd.totalP[i])
        PLess.append(PLessi)
        FLessi=float(Onestd.EERF[i])-float(Onestd.totalF[i])
        FLess.append(FLessi)
        CFratioi=float(Onestd.EERC[i])/float(Onestd.EERF[i])
        CFratio.append(CFratioi)
        CPratioi=float(Onestd.EERC[i])/float(Onestd.EERP[i])
        CPratio.append(CPratioi)
        FPratioi=float(Onestd.EERF[i])/float(Onestd.EERP[i])
        FPratio.append(FPratioi)

    # user-dataframe  
    user=pd.DataFrame({
        "userId":Onestd.userId.tolist(),
        #"rdate":Onestd.rdate.tolist(),
        "CLess":CLess,
        "PLess":PLess,
        "FLess":FLess,
        "CFratio":CFratio,
        "CPratio":CPratio,
        "FPratio":FPratio
    })
    
    print("user:\n",user)
    foodDf=getFoodList()
    foodDf.loc[0]=user.loc[0].tolist()
    #foodDf.loc[1]=user.tolist()
    #print(foodDf)
    foodDf1=foodDf.drop(['foodname'],axis="columns")
    #print(foodDf1)
    from numpy import dot 
    from numpy.linalg import norm
    import numpy as np
    def cos_sim(A, B):
        return dot(A, B)/(norm(A)*norm(B))
    cos_similarity=[]
    #유사도 행추가 
    for i in range(0,len(foodDf1)):
        doc1=np.array(foodDf1.loc[0].tolist())
        doc2=np.array(foodDf1.loc[i].tolist())
        cos_similarity.append(cos_sim(doc1,doc2))
        #print(doc1,"-",doc2,"-",cos_sim(doc1,doc2))
    foodDf["cos_similarity"]=cos_similarity
    recommend=foodDf.sort_values(['cos_similarity'],ascending=[False]).head(4)
    print(recommend)
    # 추천 음식 상위 3개 뽑아서 List로 넘겨줘야 함 
    recommendList=recommend.foodname.tolist()
    del recommendList[0]
    #print(recommendList)
    
    # 여기서 바로 recommentList를 반환하면 추천하는 음식 이름 명만 보내진다
    # 다만 추천음식에 대해 해당 영양정보를 같이 반환하고 싶으면 다음과 같이 foodRawList에서 
    # 추천음식리스트와 음식명이 일치하는 행을 불러온다 
    foodRawList=getFoodRawList()
    foodrecommend=foodRawList[foodRawList['foodname'].isin(recommendList)]
    print(foodrecommend)
    
    
    
    return foodrecommend

    
    
    
    
     
       