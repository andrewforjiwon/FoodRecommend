

## DATABASE 생성 및 선택
CREATE DATABASE IF NOT EXISTS spring;

use spring;



drop table if exists eatedinfo;

create table if not exists eatedinfo(
   no integer auto_increment primary key,
   reg_date TIMESTAMP not null,
   rdate VARCHAR(20) not null,
   rtime VARCHAR(20) not null,
   user_id VARCHAR(20) not null,
   bday VARCHAR(20) not null,
    sex VARCHAR(10) not null,
    height int(20) not null,
    weight int(20) not null,
    pa_stage int(20) not null,
    bf1 VARCHAR(30) not null,
	bf1g VARCHAR(30) not null,
    bf2 VARCHAR(30) not null,
    bf2g VARCHAR(30) not null,
    bf3 VARCHAR(30) not null,
    bf3g VARCHAR(30) not null,
    lc1 VARCHAR(30) not null,
    lc1g VARCHAR(30) not null,
    lc2 VARCHAR(30) not null,
    lc2g VARCHAR(30) not null,    
    lc3 VARCHAR(30) not null,
    lc3g VARCHAR(30) not null,
    dn1 VARCHAR(30) not null,
    dn1g VARCHAR(30) not null,
    dn2 VARCHAR(30) not null,
    dn2g VARCHAR(30) not null,
    dn3 VARCHAR(30) not null,
    dn3g VARCHAR(30) not null,
    total_k VARCHAR(30) not null,
    total_c VARCHAR(30) not null,
    total_p VARCHAR(30) not null,
    total_f VARCHAR(30) not null
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

#INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
#	VALUES (SYSDATE(),substr(SYSDATE(),1,10),substr(SYSDATE(),12,9),"jiwon","19951208","1",163,68,2,"b1","200","bb1","100","bbb1","200","l1","200","ll1","100","lll1","200","d1","20","dd1","100","ddd1","200","2622","143","89.7","181");
INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
	VALUES ("2019-10-28 11:20:20","2019-10-28","11:20:20","qwerty12","19920817","1",185,78,2,"소프트롤","200","없음","1","없음","1","밥","250","배추김치","200","데친두릅","100","햄버거","400","사이다","100","없음","1","2300","1400","60","150");
INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
	VALUES ("2019-10-29 11:20:20","2019-10-29","11:20:20","qwerty12","19920817","1",185,76,3,"소프트롤","200","없음","1","없음","1","밥","250","배추김치","200","데친두릅","100","햄버거","400","사이다","100","없음","1","3700","2700","20","230");
INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
	VALUES ("2019-10-30 11:20:20","2019-10-30","11:20:20","qwerty12","19920817","1",185,77,1,"소프트롤","200","없음","1","없음","1","밥","250","배추김치","200","데친두릅","100","햄버거","400","사이다","100","없음","1","2300","1840","45","140");
INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
	VALUES ("2019-10-31 11:20:20","2019-10-31","11:20:20","qwerty12","19920817","1",185,75,4,"소프트롤","200","없음","1","없음","1","밥","250","배추김치","200","데친두릅","100","햄버거","400","사이다","100","없음","1","3700","2300","50","170");
INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
	VALUES ("2019-11-01 11:20:20","2019-11-01","11:20:20","qwerty12","19920817","1",185,77,2,"소프트롤","200","없음","1","없음","1","밥","250","배추김치","200","데친두릅","100","햄버거","400","사이다","100","없음","1","4000","3400","70","107");
INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
	VALUES ("2019-11-02 11:20:20","2019-11-02","11:20:20","qwerty12","19920817","1",185,79,2,"소프트롤","200","없음","1","없음","1","밥","250","배추김치","200","데친두릅","100","햄버거","400","사이다","100","없음","1","3200","2600","30","200");
INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
	VALUES ("2019-11-03 11:20:20","2019-11-03","11:20:20","qwerty12","19920817","1",185,79,2,"소프트롤","200","없음","1","없음","1","밥","250","배추김치","200","데친두릅","100","햄버거","400","사이다","100","없음","1","2300","1900","30","150");
INSERT INTO eatedinfo(reg_date,rdate,rtime,user_id,bday,sex,height,weight,pa_stage,bf1,bf1g,bf2,bf2g,bf3,bf3g,lc1,lc1g,lc2,lc2g,lc3,lc3g,dn1,dn1g,dn2,dn2g,dn3,dn3g,total_k,total_c,total_p,total_f) 
	VALUES ("2019-11-04 11:20:20","2019-11-04","11:20:20","qwerty12","19920817","1",185,79,2,"소프트롤","200","없음","1","없음","1","밥","250","배추김치","200","데친두릅","100","햄버거","400","사이다","100","없음","1","2500","1800","30","200");


select * from eatedinfo; 

