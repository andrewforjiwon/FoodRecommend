use spring;

drop table if exists foodList;
set global sql_mode='';
create table if not exists foodList(
   no integer auto_increment primary key,
   classification VARCHAR(50) not null,
   foodname VARCHAR(50) not null,
   serving int(10) not null,
   kcal float(20) not null,
    car float(20) not null,
    pro float(20) not null,
    fat float(20) not null,
    sugars float(20) not null,
    salt float(20) not null,
    cholesterol float(20) not null,
    sfacid float(20) not null,
    tfacid float(20) not null
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

select @@GLOBAL.secure_file_priv;
load data infile 'C:\\ProgramData\\MySQL\\MySQL Server 5.6\\Uploads\\RealFoodList.csv' into table foodList fields terminated by ',';
COMMIT;

select * from foodList;
select count(*) from foodList